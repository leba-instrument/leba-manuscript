library(testthat)

library(dendextend)
test_check("dendextend")
# testthat::test_dir("tests/testthat/", wrap = F)



#
# library(dendextend)
# test_package("dendextend")
#
#
# library(dendextend)
# tryCatch(test_package("dendextend"),
#          error = function(e)
#             cat('Please run: testthat::test_dir("tests\\testthat")')
#          )
#
#
#
# testthat::test_dir("tests/testthat")

# library(dendextend)
# system.time(test_dir("inst\\tests")) # 12.8  (- 21)
# search()

