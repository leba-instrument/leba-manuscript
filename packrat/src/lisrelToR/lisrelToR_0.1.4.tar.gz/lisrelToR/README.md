lisrelToR
=========

This is an unofficial package aimed at automating the import of LISREL output in R. This package or its maintainer is not in any way affiliated with the creators of LISREL and SSI, Inc.