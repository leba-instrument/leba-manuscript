setGeneric("summaryShort", function(object, ...) {
    return(standardGeneric("summaryShort"))
})
