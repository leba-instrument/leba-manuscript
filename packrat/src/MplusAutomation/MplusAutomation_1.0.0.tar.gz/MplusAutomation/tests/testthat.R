library(testthat)
library(MplusAutomation)

test_check("MplusAutomation")
