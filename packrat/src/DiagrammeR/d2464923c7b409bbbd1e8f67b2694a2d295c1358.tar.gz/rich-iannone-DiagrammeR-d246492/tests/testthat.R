library(testthat)
library(DiagrammeR)

suppressWarnings(RNGversion("3.5.0"))
test_check("DiagrammeR")
