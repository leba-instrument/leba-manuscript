## Test environments
* Ubuntu 16.04.6 LTS (on github actions), devel, release, oldrel, 3.6, 3.5, 3.4
* Windows Server 2019 (on github actions), release
* macOS (on github actions), release
* win-builder devel

## R CMD check results
Maintainer: 'Daniel D. Sjoberg <danield.sjoberg@gmail.com>'

## Additional Comments

Thank you for your time.
