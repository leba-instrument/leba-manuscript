commutation.matrix <- function( r, c=r )
{
###
### this function returns a square matrix with p = r * c rows and columns
###
### Parameters
### m = integer rows
### n = integer columns
###
    return( K.matrix( r, c ) )
}
