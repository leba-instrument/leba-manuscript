.onAttach <- function(libname, pkgname) {
  packageStartupMessage("qs v0.25.1.")
}
