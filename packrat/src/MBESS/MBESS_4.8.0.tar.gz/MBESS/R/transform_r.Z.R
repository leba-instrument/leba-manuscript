transform_r.Z <- function(r)
{
  return((1/2)*log((1+r)/(1-r)))
}