#ifndef u_OMX_EXPORT_BACKEND_STATE_H
#define u_OMX_EXPORT_BACKEND_STATE_H

#include "omxDefines.h"
#include "omxState.h"

void omxPopulateFitFunction(omxMatrix *om, MxRList *result);

#endif // #define u_OMX_EXPORT_BACKEND_STATE_H
