#ifndef u_ALGEBRAOP_H_
#define u_ALGEBRAOP_H_

class omxMatrix;
typedef void (*algebra_op_t)(FitContext *fc, class omxMatrix**, int, class omxMatrix*);

#endif
