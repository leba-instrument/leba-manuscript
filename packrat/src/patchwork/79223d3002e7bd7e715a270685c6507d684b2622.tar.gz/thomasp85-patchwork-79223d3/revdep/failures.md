# NA

<details>

* Version: NA
* Source code: https://github.com/cran/NA
* Number of recursive dependencies: 0

Run `cloud_details(, "NA")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Seurat

<details>

* Version: 3.2.2
* Source code: https://github.com/cran/Seurat
* URL: https://satijalab.org/seurat, https://github.com/satijalab/seurat
* BugReports: https://github.com/satijalab/seurat/issues
* Date/Publication: 2020-09-26 04:30:12 UTC
* Number of recursive dependencies: 230

Run `cloud_details(, "Seurat")` for more info

</details>

## Error before installation

### Devel

```
* using log directory ‘/tmp/workdir/Seurat/new/Seurat.Rcheck’
* using R version 3.6.3 (2020-02-29)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using options ‘--no-manual --no-build-vignettes’
* checking for file ‘Seurat/DESCRIPTION’ ... OK
* this is package ‘Seurat’ version ‘3.2.2’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Packages suggested but not available:
  'S4Vectors', 'SummarizedExperiment', 'SingleCellExperiment', 'MAST',
  'DESeq2', 'BiocGenerics', 'GenomicRanges', 'GenomeInfoDb', 'IRanges',
  'rtracklayer', 'monocle', 'Biobase', 'limma', 'metap'

The suggested packages are required for a complete check.
Checking can be attempted without them by setting the environment
variable _R_CHECK_FORCE_SUGGESTS_ to a false value.

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR






```
### CRAN

```
* using log directory ‘/tmp/workdir/Seurat/old/Seurat.Rcheck’
* using R version 3.6.3 (2020-02-29)
* using platform: x86_64-pc-linux-gnu (64-bit)
* using session charset: UTF-8
* using options ‘--no-manual --no-build-vignettes’
* checking for file ‘Seurat/DESCRIPTION’ ... OK
* this is package ‘Seurat’ version ‘3.2.2’
* package encoding: UTF-8
* checking package namespace information ... OK
* checking package dependencies ... ERROR
Packages suggested but not available:
  'S4Vectors', 'SummarizedExperiment', 'SingleCellExperiment', 'MAST',
  'DESeq2', 'BiocGenerics', 'GenomicRanges', 'GenomeInfoDb', 'IRanges',
  'rtracklayer', 'monocle', 'Biobase', 'limma', 'metap'

The suggested packages are required for a complete check.
Checking can be attempted without them by setting the environment
variable _R_CHECK_FORCE_SUGGESTS_ to a false value.

See section ‘The DESCRIPTION file’ in the ‘Writing R Extensions’
manual.
* DONE
Status: 1 ERROR






```
