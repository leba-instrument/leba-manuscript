#' @importFrom farver convert_colour decode_colour encode_colour
#' @importFrom grDevices col2rgb rgb
#' @importFrom graphics plot rect text
NULL
