test_length(modify_hcl)

test_color_class(clr_rotate)

test_wrong_input(clr_rotate)

test_severity(clr_rotate)

test_severity_range(clr_rotate)

test_severity_0(clr_rotate, tol = 1)

test_zero_length_input(clr_rotate)
