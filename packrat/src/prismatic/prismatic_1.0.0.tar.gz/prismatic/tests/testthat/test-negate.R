test_length(clr_negate)

test_color_class(clr_negate)

test_wrong_input(clr_negate)

test_zero_length_input(clr_negate)
