fitgraph.character <-
function(fitEst,...) {
	fitgraph(CQmodel(show = fitEst),...)
}
