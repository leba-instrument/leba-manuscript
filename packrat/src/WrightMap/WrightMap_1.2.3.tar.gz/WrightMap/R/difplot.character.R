difplot.character <- function(data, equation = NULL, ...) {
	difplot(CQmodel(show = data, equation = equation), ...)
}