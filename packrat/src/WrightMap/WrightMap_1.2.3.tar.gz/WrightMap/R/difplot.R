difplot <- function(data, ...) {
	UseMethod("difplot")
}