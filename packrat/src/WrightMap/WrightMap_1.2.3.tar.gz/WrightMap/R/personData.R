personData <- function(thetas, ...) {
	UseMethod("personData")
}