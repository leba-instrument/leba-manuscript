make.thresholds <-
function(item.params,...) {
	UseMethod("make.thresholds")
}
