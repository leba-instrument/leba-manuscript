make.deltas.character <-
function(item.params, ...) {
	return(make.deltas(CQmodel(show = item.params), ...))
}
