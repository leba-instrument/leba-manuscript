fitgraph <-
function( fitEst, ...) {
	UseMethod("fitgraph")
}
