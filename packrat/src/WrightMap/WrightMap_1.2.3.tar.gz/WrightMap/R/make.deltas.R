make.deltas <-
function(item.params, ...) {
	UseMethod("make.deltas")
}
