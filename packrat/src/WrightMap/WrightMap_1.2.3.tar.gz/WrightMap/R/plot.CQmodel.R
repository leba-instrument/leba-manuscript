plot.CQmodel <-
function(x, ...) {
	wrightMap(x, ...)
}
