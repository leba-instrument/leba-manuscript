library(testthat)
library(corx)

test_check("corx")
