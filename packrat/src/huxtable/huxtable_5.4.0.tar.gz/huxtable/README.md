
<table class="huxtable" style="border-collapse: collapse; border: 0px; margin-bottom: 2em; margin-top: 2em; ; margin-left: auto; margin-right: auto;  " id="tab:unnamed-chunk-1">

<col>

<col>

<col>

<col>

<col>

<col>

<tr>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; background-color: rgb(0, 0, 255); font-weight: normal; font-family: DejaVu Sans;">

<span style="color: rgb(255, 255, 255);"></span>

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; background-color: rgb(255, 255, 0); font-weight: bold; font-family: DejaVu Sans;">

<span style="color: rgb(0, 0, 0);">h</span>

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

u

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td colspan="2" style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

</tr>

<tr>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; background-color: rgb(0, 0, 255); font-weight: normal; font-family: DejaVu Sans;">

<span style="color: rgb(255, 255, 255);"></span>

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

x

</td>

<td rowspan="2" style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

</tr>

<tr>

<td rowspan="2" style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; background-color: rgb(255, 0, 0); font-weight: normal; font-family: DejaVu Sans;">

<span style="color: rgb(255, 255, 255);"></span>

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td rowspan="2" style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

t

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; background-color: rgb(255, 255, 0); font-weight: normal; font-family: DejaVu Sans;">

<span style="color: rgb(0, 0, 0);"></span>

</td>

</tr>

<tr>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td colspan="2" style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

a

</td>

</tr>

<tr>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; background-color: rgb(255, 0, 0); font-weight: normal; font-family: DejaVu Sans;">

<span style="color: rgb(255, 255, 255);"></span>

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

b

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; background-color: rgb(255, 0, 0); font-weight: normal; font-family: DejaVu Sans;">

<span style="color: rgb(255, 255, 255);"></span>

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

l

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

</tr>

<tr>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; background-color: rgb(255, 0, 0); font-weight: normal; font-family: DejaVu Sans;">

<span style="color: rgb(255, 255, 255);"></span>

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

e

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

<td style="vertical-align: top; text-align: center; white-space: normal; border-style: solid solid solid solid; border-width: 1.2pt 1.2pt 1.2pt 1.2pt; border-top-color: rgb(0, 0, 0);  border-right-color: rgb(0, 0, 0);  border-bottom-color: rgb(0, 0, 0);  border-left-color: rgb(0, 0, 0); padding: 0pt 0pt 0pt 0pt; font-weight: normal; font-family: DejaVu Sans;">

</td>

</tr>

</table>

<!-- README.md is generated from README.Rmd. Please edit that file -->

<br>

<!-- badges: start -->

[![CRAN Status
Badge](http://www.r-pkg.org/badges/version/huxtable)](https://cran.r-project.org/package=huxtable)
[![CRAN Downloads Per
Month](http://cranlogs.r-pkg.org/badges/huxtable)](https://CRAN.R-project.org/package=huxtable)
[![R build
status](https://github.com/hughjonesd/huxtable/workflows/R-CMD-check/badge.svg)](https://github.com/hughjonesd/huxtable/actions)
[![AppVeyor Build
Status](https://ci.appveyor.com/api/projects/status/github/hughjonesd/huxtable?branch=master&svg=true)](https://ci.appveyor.com/project/hughjonesd/huxtable)
[![Coverage
Status](https://img.shields.io/codecov/c/github/hughjonesd/huxtable/master.svg)](https://codecov.io/github/hughjonesd/huxtable?branch=master)
<!-- badges: end -->

Huxtable is an R package to create styled tables in multiple output
formats, with a friendly, modern interface. Features include:

  - Control over text styling, number format, background colour,
    borders, padding and alignment.
  - Table cells can span multiple rows and/or columns.
  - Table manipulation via standard R subsetting, or using `dplyr`.
  - Automatic formatting for knitr/rmarkdown documents.
  - `huxreg()` function for quick creation of regression tables.
  - Output to HTML, LaTeX, RTF, and Microsoft Word/Excel/Powerpoint,
    using the `officer` and `openxlsx` packages.
  - Quick one-liners to print data frames into a new PDF, HTML page, RTF
    or Microsoft document.
  - Formatted table display in the R console, including borders, colour,
    and text styles.

# Installing

To install from CRAN:

``` r
install.packages('huxtable')
```

To install the latest version from github:

``` r
install.packages('remotes')
remotes::install_github('hughjonesd/huxtable')
```

# Learning more

Check out [the website](https://hughjonesd.github.io/huxtable/), read
the
[documentation](https://hughjonesd.github.io/huxtable/reference/index.html)
or read the vignette in
[HTML](https://hughjonesd.github.io/huxtable/huxtable.html) or
[PDF](https://hughjonesd.github.io/huxtable/huxtable.pdf).

# Fund huxtable development

If you find huxtable useful, [fund me on
Patreon](https://www.patreon.com/bePatron?u=19572369).
