library(testthat)
library(huxtable)


we_are_in_R_CMD_check <- TRUE
test_check("huxtable")

