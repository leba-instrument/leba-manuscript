library("testthat")
library("citr")

test_check("citr")
