## ----eval=FALSE---------------------------------------------------------------
#  install.packages("stringfish", type="source", configure.args="--with-simd=AVX2")

## ----eval=FALSE---------------------------------------------------------------
#  sf_alternate_case("hello world")
#  [1] "hElLo wOrLd"

