# Custom RcppExports edited

set_is_utf8_locale <- function() {
    invisible(.Call(`_stringfish_set_is_utf8_locale`))
}

unset_is_utf8_locale <- function() {
    invisible(.Call(`_stringfish_unset_is_utf8_locale`))
}

get_is_utf8_locale <- function() {
    .Call(`_stringfish_get_is_utf8_locale`)
}

is_tbb <- function() {
    .Call(`_stringfish_is_tbb`)
}

check_simd <- function() {
    invisible(.Call(`_stringfish_check_simd`))
}

get_pcre2_info <- function() {
    .Call(`_stringfish_get_pcre2_info`)
}

get_string_type <- function(x) {
    .Call(`_stringfish_get_string_type`, x)
}

materialize <- function(x) {
    .Call(`_stringfish_materialize`, x)
}

sf_vector <- function(len) {
    .Call(`_stringfish_sf_vector`, len)
}

sf_assign <- function(x, i, e) {
    invisible(.Call(`_stringfish_sf_assign`, x, i, e))
}

sf_iconv <- function(x, from, to, nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_sf_iconv`, x, from, to, nthreads)
}

convert_to_sf <- function(x) {
    .Call(`_stringfish_convert_to_sf`, x)
}

sf_nchar <- function(x, type = "chars", nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_sf_nchar`, x, type, nthreads)
}

sf_substr <- function(x, start, stop, nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_sf_substr`, x, start, stop, nthreads)
}

c_sf_paste <- function(dots, sep, nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_c_sf_paste`, dots, sep, nthreads)
}

sf_collapse <- function(x, collapse) {
    .Call(`_stringfish_sf_collapse`, x, collapse)
}

sf_readLines <- function(file, encoding = "UTF-8") {
    .Call(`_stringfish_sf_readLines`, file, encoding)
}

sf_writeLines <- function(text, file, sep = "\n", na_value = "NA", encode_mode = "UTF-8") {
    invisible(.Call(`_stringfish_sf_writeLines`, text, file, sep, na_value, encode_mode))
}

sf_grepl <- function(subject, pattern, encode_mode = "auto", fixed = FALSE, nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_sf_grepl`, subject, pattern, encode_mode, fixed, nthreads)
}

sf_split <- function(subject, split, encode_mode = "auto", fixed = FALSE, nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_sf_split`, subject, split, encode_mode, fixed, nthreads)
}

sf_gsub <- function(subject, pattern, replacement, encode_mode = "auto", fixed = FALSE, nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_sf_gsub`, subject, pattern, replacement, encode_mode, fixed, nthreads)
}

random_strings <- function(N, string_size = 50L, charset = "abcdefghijklmnopqrstuvwxyz", vector_mode = "stringfish") {
    .Call(`_stringfish_random_strings`, N, string_size, charset, vector_mode)
}

sf_tolower <- function(x) {
    .Call(`_stringfish_sf_tolower`, x)
}

sf_toupper <- function(x) {
    .Call(`_stringfish_sf_toupper`, x)
}

sf_match <- function(x, table, nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_sf_match`, x, table, nthreads)
}

sf_compare <- function(x, y, nthreads = getOption("stringfish.nthreads", 1L)) {
    .Call(`_stringfish_sf_compare`, x, y, nthreads)
}

c_sf_concat <- function(x) {
    .Call(`_stringfish_c_sf_concat`, x)
}

