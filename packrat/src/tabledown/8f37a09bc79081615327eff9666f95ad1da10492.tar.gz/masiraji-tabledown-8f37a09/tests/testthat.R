library(testthat)
library(tabledown)

test_check("tabledown")
