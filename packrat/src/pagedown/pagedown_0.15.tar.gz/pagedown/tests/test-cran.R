testit::test_pkg('pagedown', 'test-cran')
