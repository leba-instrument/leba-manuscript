# bibtex

[![Travis-CI Build Status](https://travis-ci.org/romainfrancois/bibtex.svg?branch=master)](https://travis-ci.org/romainfrancois/bibtex)

## Installation

You can install bibtex from github with:

```R
# install.packages("devtools")
devtools::install_github("romainfrancois/bibtex")
```

