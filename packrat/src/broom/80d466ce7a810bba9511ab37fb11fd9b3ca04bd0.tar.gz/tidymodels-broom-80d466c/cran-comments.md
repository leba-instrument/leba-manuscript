# broom 0.7.9

## Test environments

* local OS X install, R 4.1.0
* ubuntu 18.04 (on github actions), devel, release, oldrel
* windows (on github actions), release
* OS X (on github actions), release
* windows (on win-builder), devel

## R CMD check results

0 WARNINGS, 0 ERRORS, 0 NOTES.

# Reverse dependencies

We checked 190 reverse dependencies (175 from CRAN + 15 from BioConductor), 
comparing R CMD check results across CRAN and dev versions of this package.
We saw no new ERRORs, WARNINGs, or NOTEs.
