#' @param type.predict Character indicating type of prediction to use. Passed
#'   to the `type` argument of the [stats::predict()] generic. Allowed arguments
#'   vary with model class, so be sure to read the `predict.my_class`
#'   documentation.
#' @md
