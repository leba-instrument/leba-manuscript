#' @param interval Character indicating the type of confidence interval columns
#'  to be added to the augmented output. Passed on to `predict()` and defaults 
#'  to "none".
#' @md
